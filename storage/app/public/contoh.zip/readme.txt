Token: ZRvqgoNkl3IV3VMGyhVzEdP8ChaVWO
Name: LKS Nasional 2024
Category: LKSN
Summary: module ini akan menugaskan membuat web app kalkulator
Module Filename: module.docx
Media Filename: media_file.zip
Marking Filename: marking.xlsx